package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import conexao.ConexaoDb;
import entidade.Sala;

public class SalaDao extends ConexaoDb{

	final String SQL_INSERT_SALA = "INSERT INTO SALA (NUMERO_SALA, QNT_ALUNOS, ID_PROFESSOR, ID_ORIENTADOR) VALUES ( ?, ?, ?, ?)";
	final String SQL_SELECT_SALA = "SELECT * FROM SALA";
	final String SQL_SELECT_SALA_ID = "SELECT * FROM SALA WHERE NUMERO_SALA = ?";
	final String SQL_ALTERA_SALA = "UPDATE SALA SET QNT_ALUNOS = ? ID_PROFESSOR = ? ID_ORIENTADOR = ? WHERE NUMERO_SALA = ?";
	final String DELETA_SALA = "DELETE FROM SALA WHERE NUMERO_SALA = ?";
	
	public int inserir(Sala sala){
		int quantidade = 0;

		try (Connection connection = this.conectar();
			PreparedStatement pst = connection.prepareStatement(SQL_INSERT_SALA);) {
			pst.setInt(1, sala.getNum_sala());
			pst.setInt(2, sala.getQnt_alunos());
			pst.setInt(3, sala.getID_professor());
			pst.setInt(4, sala.getID_orientador());
			quantidade = pst.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return quantidade;
	}
	
	public List<Sala> listAll(){
		List<Sala> listaSala = new ArrayList<Sala>();
		
		try (Connection connection = this.conectar();
				PreparedStatement pst = connection.prepareStatement(SQL_SELECT_SALA);){

			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				Sala sala = new Sala();
				sala.setNum_sala(rs.getInt("NUMERO_SALA"));
				sala.setQnt_alunos(rs.getInt("QNT_ALUNOS"));
				sala.setID_professor(rs.getInt("ID_PROFESSOR"));
				sala.setID_orientador(rs.getInt("ID_ORIENTADOR"));
				listaSala.add(sala);
				System.out.println(sala);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return listaSala;
	}
	
	
	public Sala findByID (int id) {
		Sala sala = null;
		try (Connection connection = this.conectar();
				PreparedStatement pst = connection.prepareStatement(SQL_SELECT_SALA_ID)){

			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				sala = new Sala();
				sala.setNum_sala(rs.getInt("NUMERO_SALA"));
				sala.setQnt_alunos(rs.getInt("QNT_ALUNOS"));
				sala.setID_professor(rs.getInt("ID_PROFESSOR"));
				sala.setID_orientador(rs.getInt("ID_ORIENTADOR"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return sala;
	}
	
	
	public int alterar(Sala sala) {
		int quantidade = 0;

		try (Connection connection = this.conectar();
			PreparedStatement pst = connection.prepareStatement(SQL_ALTERA_SALA);) {
			pst.setInt(1, sala.getNum_sala());
			pst.setInt(2, sala.getQnt_alunos());
			pst.setInt(3, sala.getID_professor());
			pst.setInt(4, sala.getID_orientador());
			quantidade = pst.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return quantidade;
	}
	
	public int deletar(int id) {
        int quantidade = 0;
        try (Connection connection = this.conectar();
            PreparedStatement pst = connection.prepareStatement(DELETA_SALA);) {
            pst.setInt(1, id);
            quantidade = pst.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
        return quantidade;
    }
	
}
