package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import conexao.ConexaoDb;
import entidade.Orientador;

public class OrientadorDao extends ConexaoDb {
	
	final String SQL_INSERT_Orientador = "INSERT INTO Orientador (NOME, EMAIL, ESCOLA, PESO, DATA_ADMISSAO) VALUES ( ?, ?, ?, ?, ?)";
	final String SQL_SELECT_Orientador = "SELECT * FROM Orientador";
	final String SQL_SELECT_Orientador_ID = "SELECT * FROM Orientador WHERE ID = ?";
	final String SQL_ALTERA_Orientador = "UPDATE Orientador SET NOME=?, EMAIL=?, ESCOLA=?, PESO=?, DATA_ADMISSAO=? WHERE ID=?";
	final String DELETA_Orientador = "DELETE FROM Orientador WHERE ID = ?";
	
	public int inserir(Orientador orientador) {
		int quantidade = 0;

		try (Connection connection = this.conectar();
			PreparedStatement pst = connection.prepareStatement(SQL_INSERT_Orientador);) {
			pst.setString(1, orientador.getNome());
			pst.setString(2, orientador.getEmail());
			pst.setString(3, orientador.getEscola());
			pst.setDouble(4, orientador.getPeso());
			pst.setDate(5,Date.valueOf(orientador.getData_admissao().toString()));
			quantidade = pst.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return quantidade;
	}
	
	
	
	public List<Orientador> listAll(){
		List<Orientador> listaOrientador = new ArrayList<Orientador>();
		
		try (Connection connection = this.conectar();
				PreparedStatement pst = connection.prepareStatement(SQL_SELECT_Orientador);){

			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				Orientador orientador = new Orientador();
				
				orientador.setId(rs.getInt("ID"));
				orientador.setNome(rs.getString("NOME"));
				orientador.setEmail(rs.getString("EMAIL"));
				orientador.setEscola(rs.getString("ESCOLA"));
				orientador.setPeso(rs.getDouble("PESO"));
				orientador.setData_admissao(Date.valueOf((rs.getString("DATA_ADMISSAO"))));
				
				listaOrientador.add(orientador);
				System.out.println(orientador);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return listaOrientador;
	}
		
		
		
		public Orientador findByID (int id) {
			Orientador orientador = null;
			try (Connection connection = this.conectar();
					PreparedStatement pst = connection.prepareStatement(SQL_SELECT_Orientador_ID)){

				pst.setInt(1, id);
				ResultSet rs = pst.executeQuery();
				
				while(rs.next()) {
					orientador = new Orientador();
					
					orientador.setId(rs.getInt("ID"));
					orientador.setNome(rs.getString("NOME"));
					orientador.setEmail(rs.getString("EMAIL"));
					orientador.setEscola(rs.getString("ESCOLA"));
					orientador.setPeso(rs.getDouble("PESO"));
					orientador.setData_admissao(rs.getDate("DATA_ADMISSAO"));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			return orientador;
		}



		public int alterar(Orientador orientador) {
			int quantidade = 0;

			try (Connection connection = this.conectar();
				PreparedStatement pst = connection.prepareStatement(SQL_ALTERA_Orientador);) {
				pst.setString(1, orientador.getNome());
				pst.setString(2, orientador.getEmail());
				pst.setString(3, orientador.getEscola());
				pst.setDouble(4, orientador.getPeso());
				pst.setDate(5, Date.valueOf(orientador.getData_admissao().toString()));
				pst.setInt(6, orientador.getId());
				quantidade = pst.executeUpdate();

			} catch (SQLException e) {
				e.printStackTrace();
			}

			return quantidade;
		}
		
		public int deletar(int id) {
	        int quantidade = 0;
	        try (Connection connection = this.conectar();
	            PreparedStatement pst = connection.prepareStatement(DELETA_Orientador);) {
	            pst.setInt(1, id);
	            quantidade = pst.executeUpdate();
	        } catch (Exception e) {
	            System.out.println(e);
	        }
	        return quantidade;
	    }
	}
