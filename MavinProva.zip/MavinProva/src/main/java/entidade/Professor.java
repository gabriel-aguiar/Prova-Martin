package entidade;

import java.sql.Date;

public class Professor  extends Pessoa{
	
	private String turma;
	private Double peso;
	private Date data_admissao;
	
	public Professor(String turma, Double peso, Date data_admissao, String nome, String email) {
		super(nome, email);
		this.turma = turma;
		this.peso = peso;
		this.data_admissao = data_admissao;	
	}
	
	public Professor(String turma, Double peso, Date data_admissao, int id, String nome, String email) {
		super(id, nome, email);
		this.turma = turma;
		this.peso = peso;
		this.data_admissao = data_admissao;	
	}


	public Professor() {
		
	}

	public String getTurma() {
		return turma;
	}

	public void setTurma(String turma) {
		this.turma = turma;
	}

	public Double getPeso() {
		return peso;
	}

	public void setPeso(Double peso) {
		this.peso = peso;
	}

	public Date getData_admissao() {
		return data_admissao;
	}

	public void setData_admissao(Date data_admissao) {
		this.data_admissao = data_admissao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((data_admissao == null) ? 0 : data_admissao.hashCode());
		result = prime * result + ((peso == null) ? 0 : peso.hashCode());
		result = prime * result + ((turma == null) ? 0 : turma.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Professor other = (Professor) obj;
		if (data_admissao == null) {
			if (other.data_admissao != null)
				return false;
		} else if (!data_admissao.equals(other.data_admissao))
			return false;
		if (peso == null) {
			if (other.peso != null)
				return false;
		} else if (!peso.equals(other.peso))
			return false;
		if (turma == null) {
			if (other.turma != null)
				return false;
		} else if (!turma.equals(other.turma))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Professor [turma=" + turma + ", peso=" + peso + ", data_admissao=" + data_admissao + ", getId()="
				+ getId() + ", getNome()=" + getNome() + ", getEmail()=" + getEmail() + ", toString()="
				+ super.toString() + ", getClass()=" + getClass() + "]";
	}

	
	
}
