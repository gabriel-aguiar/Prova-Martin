package entidade;

public class Sala {
	
	private int num_sala;
	private int qnt_alunos;
	private int ID_professor;
	private int ID_orientador;
	
	public Sala() {
		
	}
	
	public Sala(int qnt_alunos, int iD_professor, int iD_orientador) {
		super();
		this.qnt_alunos = qnt_alunos;
		ID_professor = iD_professor;
		ID_orientador = iD_orientador;
	}
	
	public Sala(int num_sala, int qnt_alunos, int iD_professor, int iD_orientador) {
		super();
		this.num_sala = num_sala;
		this.qnt_alunos = qnt_alunos;
		ID_professor = iD_professor;
		ID_orientador = iD_orientador;
	}
	
	public int getNum_sala() {
		return num_sala;
	}
	public void setNum_sala(int num_sala) {
		this.num_sala = num_sala;
	}
	public int getQnt_alunos() {
		return qnt_alunos;
	}
	public void setQnt_alunos(int qnt_alunos) {
		this.qnt_alunos = qnt_alunos;
	}
	public int getID_professor() {
		return ID_professor;
	}
	public void setID_professor(int iD_professor) {
		ID_professor = iD_professor;
	}
	public int getID_orientador() {
		return ID_orientador;
	}
	public void setID_orientador(int iD_orientador) {
		ID_orientador = iD_orientador;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ID_orientador;
		result = prime * result + ID_professor;
		result = prime * result + num_sala;
		result = prime * result + qnt_alunos;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Sala other = (Sala) obj;
		if (ID_orientador != other.ID_orientador)
			return false;
		if (ID_professor != other.ID_professor)
			return false;
		if (num_sala != other.num_sala)
			return false;
		if (qnt_alunos != other.qnt_alunos)
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "Sala [num_sala=" + num_sala + ", qnt_alunos=" + qnt_alunos + ", ID_professor=" + ID_professor
				+ ", ID_orientador=" + ID_orientador + "]";
	}
	
}
