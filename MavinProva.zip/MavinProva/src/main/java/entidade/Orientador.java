package entidade;

import java.sql.Date;

public class Orientador extends Pessoa{
	
	private String escola;
	private Double peso;
	private Date data_admissao;
	
	public Orientador(String escola, Double peso, Date data_admissao, String nome, String email) {
		super(nome, email);
		this.escola = escola;
		this.peso = peso;
		this.data_admissao = data_admissao;	
	}
	
	public Orientador(String escola, Double peso, Date data_admissao, int id, String nome, String email) {
		super(id, nome, email);
		this.escola = escola;
		this.peso = peso;
		this.data_admissao = data_admissao;	
	}
	
	public Orientador() {
		
	}

	public String getEscola() {
		return escola;
	}

	public void setEscola(String escola) {
		this.escola = escola;
	}

	public Double getPeso() {
		return peso;
	}

	public void setPeso(Double peso) {
		this.peso = peso;
	}

	public Date getData_admissao() {
		return data_admissao;
	}

	public void setData_admissao(Date data_admissao) {
		this.data_admissao = data_admissao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((data_admissao == null) ? 0 : data_admissao.hashCode());
		result = prime * result + ((escola == null) ? 0 : escola.hashCode());
		result = prime * result + ((peso == null) ? 0 : peso.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Orientador other = (Orientador) obj;
		if (data_admissao == null) {
			if (other.data_admissao != null)
				return false;
		} else if (!data_admissao.equals(other.data_admissao))
			return false;
		if (escola == null) {
			if (other.escola != null)
				return false;
		} else if (!escola.equals(other.escola))
			return false;
		if (peso == null) {
			if (other.peso != null)
				return false;
		} else if (!peso.equals(other.peso))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Orientador [escola=" + escola + ", peso=" + peso + ", data_admissao=" + data_admissao + ", getId()="
				+ getId() + ", getNome()=" + getNome() + ", getEmail()=" + getEmail() + ", toString()="
				+ super.toString() + ", getClass()=" + getClass() + "]";
	}

	
	
}
