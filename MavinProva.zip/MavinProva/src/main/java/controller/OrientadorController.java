package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import dao.OrientadorDao;
import entidade.Orientador;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class OrientadorController extends Application implements Initializable{

 	@FXML
    private TextField tf_nome_orientador;

    @FXML
    private TextField tf_email_orientador;
    
    @FXML
    private TextField tf_escola_orientador;

    @FXML
    private Button btn_adicionar_prof;

    @FXML
    private Button btn_excluir_prof;

    @FXML
    private TextArea ta_lista_professor;

    @FXML
    private Button btn_edita_prof;
    
    @FXML
    private Button btn_buscar_prof;
    
    @FXML
    private DatePicker datePickerEmissao;

    @FXML
    private Label label_id;
    
    @FXML
    private Label label_label;

    @FXML
    private TextField tx_busca_id;
    
    @FXML
    private Button btn_sair_cliente;
    
    @FXML
    private TextField tx_Cpf_orientador;
    
    @FXML
    void buscarOrientador(ActionEvent event) {

    	String idString = tx_busca_id.getText();
		Orientador pessoa = null;
		if (!idString.equals("")) {
			try {
				int id = Integer.valueOf(idString);
				pessoa = new OrientadorDao().findByID(id);
			} catch (Exception e) {

			}

			if (pessoa != null) {
				label_id.setVisible(true);
				label_label.setVisible(true);
				label_label.setText(pessoa.getId() + "");
				tf_nome_orientador.setText(pessoa.getNome());
				tf_email_orientador.setText(pessoa.getEmail());
				tf_escola_orientador.setText(pessoa.getEscola());
				tx_Cpf_orientador.setText(pessoa.getPeso() + "");
				datePickerEmissao.setValue(pessoa.getData_admissao().toLocalDate());
			}

		}
		tx_busca_id.clear();
    	
    }
    
    @FXML
    void inserirOrientador(ActionEvent event) {
	
    	Orientador orientador = pegaDados();
    	limpaCampos();
    	int qtde = new OrientadorDao().inserir(orientador);
    	listarOrientador();
    	System.out.println(qtde);
	
    }
    
    @FXML
    void AlterarOrientador(ActionEvent event) {

    	Orientador orientador = pegaDadosID();
		limpaCampos();
		int qtde = new OrientadorDao().alterar(orientador);
		listarOrientador();
    	
    }
    
    @FXML
    void excluiOrientador(ActionEvent event) {
    	Alert alert = new Alert(AlertType.CONFIRMATION);
    	alert.setTitle("Deletar Orientador");
    	alert.setContentText("Tem certeza que deseja deletar o Professor?");
    	Optional<ButtonType> result = alert.showAndWait();
    	if (result.get() == ButtonType.OK){
    		Orientador Orientador = pegaDadosID();
    		int qtde = new OrientadorDao().deletar(Orientador.getId());
    		listarOrientador();
    	}
    	limpaCampos();
    	}
    	
    
    private Orientador pegaDados() {
		return new Orientador(tf_escola_orientador.getText(), Double.valueOf(tx_Cpf_orientador.getText()), Date.valueOf(datePickerEmissao.getValue()), tf_nome_orientador.getText(), tf_email_orientador.getText());
	}
	
	private Orientador pegaDadosID() {
		return new Orientador(tf_escola_orientador.getText(), Double.valueOf(tx_Cpf_orientador.getText()), Date.valueOf(datePickerEmissao.getValue()), Integer.valueOf(label_label.getText()), tf_nome_orientador.getText(), tf_email_orientador.getText());
	}

	private void limpaCampos() {
		tx_Cpf_orientador.clear();
		tf_email_orientador.clear();
		tf_nome_orientador.clear();
		tf_escola_orientador.clear();
		tf_nome_orientador.requestFocus();
		label_id.setVisible(false);
		label_label.setVisible(false);
		label_label.setText("");
		datePickerEmissao.setValue(null);
	}
	
    
    private void listarOrientador() {
    	ta_lista_professor.clear();
		List<Orientador> listaOrientador = new OrientadorDao().listAll();
		listaOrientador.forEach(pessoa -> {
			ta_lista_professor.appendText(pessoa.toString() + "\n");
		});
	}
    
    @FXML
    void BTNSairsistema(ActionEvent event) {
    	Stage stage = (Stage) btn_sair_cliente.getScene().getWindow();
    	stage.close();
    }
    
    
	public void execute() {
		launch();
	}

	@Override
	public void start(Stage stage) {

		try {
			AnchorPane pane = (AnchorPane) FXMLLoader.load(getClass().getResource("CENTRAL.fxml"));
			Scene sc = new Scene(pane);
			stage.setScene(sc);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		listarOrientador();		
	}
	

}
