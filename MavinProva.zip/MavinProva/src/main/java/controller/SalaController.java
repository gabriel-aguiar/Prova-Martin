package controller;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import dao.SalaDao;
import entidade.Sala;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class SalaController extends Application implements Initializable{
	
	@FXML
    private TextField tf_qnt_alu;

    @FXML
    private Button btn_adicionar_prof;

    @FXML
    private Button btn_excluir_prof;

    @FXML
    private TextArea ta_lista_professor;

    @FXML
    private Button btn_edita_prof;
    
    @FXML
    private Button btn_sair_cliente;

    @FXML
    private Label label_id;

    @FXML
    private TextField tx_busca_id;

    @FXML
    private Button btn_buscar_prof;

    @FXML
    private Label label_label;

    @FXML
    private TextField tx_id_orientador;

    @FXML
    private TextField tf_id_professor;

	
	    
	    @FXML
	    void buscarSala(ActionEvent event) {

	    	String idString = tx_busca_id.getText();
	    	Sala equipamento = null;
			if (!idString.equals("")) {
				try {
					int id = Integer.valueOf(idString);
					equipamento = new SalaDao().findByID(id);
				} catch (Exception e) {

				}

				if (equipamento != null) {
					label_label.setVisible(true);
					label_label.setText(equipamento.getNum_sala() + "");
					tf_qnt_alu.setText(equipamento.getQnt_alunos() + "");
					tx_id_orientador.setText(equipamento.getID_orientador() + "");
					tf_id_professor.setText(equipamento.getID_professor() + "");
				}

			}
			tx_busca_id.clear();
	    	
	    }
	
	@FXML
  void inserirSala(ActionEvent event) {
	
	Sala equipamento = pegaDados();
  	limpaCampos();
  	int qtde = new SalaDao().inserir(equipamento);
  	listaSala();
  	System.out.println(qtde);
	
  }
	
	
	private void limpaCampos() {
		
		tf_id_professor.clear();
		tf_qnt_alu.clear();
		tx_id_orientador.clear();	

	}
	
  
  private void listaSala() {
	  ta_lista_professor.clear();
		List<Sala> listaSala = new SalaDao().listAll();
		listaSala.forEach(pessoa -> {
			ta_lista_professor.appendText(pessoa.toString() + "\n");
		});
	}
  
  @FXML
  void AlterarSala(ActionEvent event) {

	  Sala sala = pegaDadosID();
		limpaCampos();
		int qtde = new SalaDao().alterar(sala);
		listaSala();
  	
  }
  
  @FXML
  void excluiSala(ActionEvent event) {
  	Alert alert = new Alert(AlertType.CONFIRMATION);
  	alert.setTitle("Deletar Equipamento");
  	alert.setContentText("Tem certeza que deseja deletar o Equipamento?");
  	Optional<ButtonType> result = alert.showAndWait();
  	if (result.get() == ButtonType.OK){
  		Sala Professor = pegaDadosID();
  		int qtde = new SalaDao().deletar(Professor.getNum_sala());
  		listaSala();
  	}
  	limpaCampos();
  	}

  	private Sala pegaDados() {
		return new Sala (Integer.valueOf(tf_qnt_alu.getText()), Integer.valueOf(tx_id_orientador.getText()), Integer.valueOf(tf_id_professor.getText()));
	}
  
	private Sala pegaDadosID() {
		return new Sala (Integer.valueOf(label_label.getText()), Integer.valueOf(tf_qnt_alu.getText()), Integer.valueOf(tf_id_professor.getText(), Integer.valueOf(tx_id_orientador.getText())));
	}
	
	
	@FXML
    void BTNSairsistema(ActionEvent event) {
    	Stage stage = (Stage) btn_sair_cliente.getScene().getWindow();
    	stage.close();
    }
	
	
	public void execute() {
		launch();
	}

	@Override
	public void start(Stage stage){
		
		try {
          AnchorPane pane = (AnchorPane) FXMLLoader.load(getClass().getResource("ViewEquipamentos.fxml"));
          Scene sc = new Scene(pane);
          stage.setScene(sc);
          stage.show();
      } catch (IOException e) {
          e.printStackTrace();
      } 
		
	}
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		listaSala();
	}
	
}
